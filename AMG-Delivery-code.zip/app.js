function sendOrder(){
  const name=document.getElementById("name").value.trim();
  const phone=document.getElementById("phone").value.trim();
  const address=document.getElementById("address").value.trim();
  const medicine=document.getElementById("medicine").value.trim();
  const msg=document.getElementById("msg");

  if(!name||!phone||!address||!medicine){
    msg.textContent="সব তথ্য পূরণ করুন।";
    return;
  }

  const text =
`AMG Delivery - নতুন অর্ডার
নাম: ${name}
মোবাইল: ${phone}
ঠিকানা: ${address}
ওষুধ: ${medicine}`;

  const whatsappNumber="8801890042002";
  window.open("https://wa.me/"+whatsappNumber+"?text="+encodeURIComponent(text),"_blank");
  msg.textContent="WhatsApp খুলছে...";
}